package test.com.mqtt.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

public class MainActivity extends AppCompatActivity{
    Button button,b1,b2,b3,b4,b5,b6,b7,b8,b9,b10;
    String content= "";
    MqttClient sampleClient1;
    String topic        = "paho/zd";
    int qos             = 0;
    String broker       = "tcp://iot.eclipse.org:1883";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button= (Button) findViewById(R.id.pub);
        b1=(Button)findViewById(R.id.lon);
        b2=(Button)findViewById(R.id.rdis);
        b3=(Button)findViewById(R.id.ren);
        b4=(Button)findViewById(R.id.rlo);
        b5=(Button)findViewById(R.id.runl);
        b6=(Button)findViewById(R.id.subbtn);
        b7 = (Button) findViewById(R.id.tbloff);
        b8 = (Button) findViewById(R.id.tblon);
        b9 = (Button) findViewById(R.id.fanoff);
        b10 = (Button) findViewById(R.id.fanon);


        String broker       = "tcp://iot.eclipse.org:1883";
        String clientId     = "paho/batch5";
        MemoryPersistence persistence = new MemoryPersistence();

        try {
            sampleClient1 = new MqttClient(broker, clientId, persistence);
        } catch (MqttException e1) {
            e1.printStackTrace();
        }



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content="0";
                publish();
                Toast.makeText(getApplicationContext(),"Light Off",Toast.LENGTH_SHORT).show();

            }
        });
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content="1";
                publish();
                Toast.makeText(getApplicationContext(),"Light On",Toast.LENGTH_SHORT).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content="2";
                publish();
                Toast.makeText(getApplicationContext(),"RFID Disable",Toast.LENGTH_SHORT).show();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content="3";
                publish();
                Toast.makeText(getApplicationContext(),"RFID Enable",Toast.LENGTH_SHORT).show();
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content="5";
                publish();
                Toast.makeText(getApplicationContext(),"Door Lock",Toast.LENGTH_SHORT).show();
            }
        });
        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content="4";
                publish();
                Toast.makeText(getApplicationContext(),"Door Unlock",Toast.LENGTH_SHORT).show();
            }
        });
        b6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               Intent i=new Intent(getApplicationContext(),SubscribeActivity.class);
                startActivity(i);


            }
        });
        b7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content = "6";
                publish();
                Toast.makeText(getApplicationContext(), "Tubelight off", Toast.LENGTH_SHORT).show();
            }
        });
        b8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content = "7";
                publish();
                Toast.makeText(getApplicationContext(), "Tubelight on", Toast.LENGTH_SHORT).show();
            }
        });
        b9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content = "8";
                publish();
                Toast.makeText(getApplicationContext(), "Fan Off", Toast.LENGTH_SHORT).show();
            }
        });
        b10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                content = "9";
                publish();
                Toast.makeText(getApplicationContext(), "Fan On", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void publish() {

        int qos             = 0;
        String broker       = "tcp://iot.eclipse.org:1883";
        String clientId     = "paho/batch";

        MemoryPersistence persistence = new MemoryPersistence();
        try {
            MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);

//            Toast.makeText(getApplicationContext(),"Connecting to broker: "+broker,Toast.LENGTH_SHORT).show();
            //System.out.println("Connecting to broker: " + broker);
            sampleClient.connect(connOpts);
//            Toast.makeText(getApplicationContext(),"Connected",Toast.LENGTH_SHORT).show();
            //System.out.println("Connected");
//            Toast.makeText(getApplicationContext(),"Publishing message: "+content,Toast.LENGTH_SHORT).show();
            //System.out.println("Publishing message: " + content);
            MqttMessage message = new MqttMessage(content.getBytes());
            message.setQos(qos);
            sampleClient.publish(topic, message);
            //   Toast.makeText(getApplicationContext(),"Message published",Toast.LENGTH_SHORT).show();
            //System.out.println("Message published");
           // sampleClient.disconnect();
            //        Toast.makeText(getApplicationContext(),"Disconnected",Toast.LENGTH_SHORT).show();
            //System.out.println("Disconnected");
        } catch(MqttException me) {
            //System.out.println("reason "+me.getReasonCode());
            //System.out.println("msg "+me.getMessage());
            //System.out.println("loc "+me.getLocalizedMessage());
            //System.out.println("cause "+me.getCause());
            //System.out.println("excep "+me);
            me.printStackTrace();
        }
    }


}
