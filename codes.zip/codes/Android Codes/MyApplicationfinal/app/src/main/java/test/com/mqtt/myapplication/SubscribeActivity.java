package test.com.mqtt.myapplication;

import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.eclipse.paho.client.mqttv3.IMqttDeliveryToken;
import org.eclipse.paho.client.mqttv3.MqttCallback;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence;

import java.util.Objects;
import java.util.logging.Handler;

public class SubscribeActivity extends AppCompatActivity{

    TextView tv,tvhum,tvmot,tvfa,buse;
    String msg="00000000";//default value
    long temp,mot,fir,bul,tub,fan,dor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_subscribe);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        Button fab = (Button) findViewById(R.id.fab);
        tv = (TextView)findViewById(R.id.temptv);
        tvhum = (TextView)findViewById(R.id.humid);
        tvmot = (TextView)findViewById(R.id.motion);
        tvfa = (TextView) findViewById(R.id.fn);
        buse = (TextView) findViewById(R.id.busec);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {



                Thread t = new Thread(new Sub());
                t.start();
                if(!msg.equals("the payload"))
                {
                    Integer a=Integer.parseInt(msg);
                    int b=a;
                    temp = b / 1000000;
                    mot = b % 1000000;
                    mot = mot / 100000;
                    fir = b % 100000;
                    fir = fir / 10000;
                    bul = b % 10000;
                    bul = bul /1000;
                    tub = b % 1000;
                    tub = tub / 100;
                    fan = b % 100;
                    fan = fan / 10;
                    dor = b % 10;
                    System.out.println("ret"+msg);
                    tv.setText("Temperature: " + temp);
                    if(bul==0)tvhum.setText("Bulb: OFF" );
                    if(bul==1)tvhum.setText("Bulb: ON" );
                    if(tub==0)tvmot.setText("Tubelight: OFF" );
                    if(tub==1)tvmot.setText("Tubelight: ON" );
                    if(fan==0)tvfa.setText("Fan: OFF");
                    if(fan==1)tvfa.setText("Fan: ON");
                    if(dor==0)buse.setText("Door Lock: OFF");
                    if(dor==1)buse.setText("Door Lock: ON");
                }


            }
        });

        //tv.setText(msg);

    }


    private class Sub implements Runnable{

        @Override
        public void run() {
            try {
                subscribe();
               // System.out.println("msg: " + msg);
            } catch (MqttException e) {
                e.printStackTrace();
            }
        }
        public void subscribe() throws MqttException {

            String topic        = "paho/batch5a";
            int qos             = 0;
            String broker       = "tcp://iot.eclipse.org:1883";
            String clientId     = "paho/batnik";
            String message = "";
            MemoryPersistence persistence = new MemoryPersistence();

            MqttClient sampleClient = new MqttClient(broker, clientId, persistence);
            MqttConnectOptions connOpts = new MqttConnectOptions();
            connOpts.setCleanSession(true);

            sampleClient.setCallback(new SubscribeCallBack());
            sampleClient.connect();
            sampleClient.subscribe(topic, qos);



        }
        class SubscribeCallBack implements MqttCallback {

            @Override
            public void connectionLost(Throwable cause) {

                Toast.makeText(getApplicationContext(),"Connection Lost",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void messageArrived(String topic, MqttMessage message) throws Exception {

                msg=message.toString();
                //Log.e("Subscribe", " " + message.toString());
                //tv.setText("Temperature: "+message.toString());
                if(!msg.equals("the payload"))
                {
                    if(!msg.equals("00000000"))
                        Toast.makeText(getApplicationContext(),"Connection Established",Toast.LENGTH_SHORT).show();
                }
                System.out.println("Data" + msg.toString());
            }

            @Override
            public void deliveryComplete(IMqttDeliveryToken token) {
                Toast.makeText(getApplicationContext(),"Got It",Toast.LENGTH_SHORT).show();
            }


        }
    }





}
